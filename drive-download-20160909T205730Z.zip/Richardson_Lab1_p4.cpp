#include <iostream> 
using namespace std;
int main()
{
	double Num1, Num2, Num3,total, avg;
	Num1 = 101.23;
	Num2 = 62.33;
	Num3 = 91.3;
	total = Num1 + Num2 + Num3;
	avg = total / 3.0;
	cout << "total=" <<total<< "\n"  ;
	cout << "average=" <<avg<< "\n" ;
	system("pause");
	return 0;
}