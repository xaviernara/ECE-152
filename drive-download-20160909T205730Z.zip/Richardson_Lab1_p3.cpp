
#include <iostream> 
using namespace std;
int main()
{
	int length, width, height, volume;
	length = 60;
	width = 50;
	height = 40;
	volume = length*width*height;
	cout << "volume = "<<volume<<"\n";
	system("pause");
	return 0;
}


