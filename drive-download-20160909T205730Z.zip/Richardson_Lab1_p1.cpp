#include <iostream>
using namespace std;
int main()
{
	cout << "Little Star\n\n"
		"Twinkle, twinkle, little star!\n"
		"How I wonder wha you are\n"
		"Up above the world so high,\n"
		"Like a diamond in the sky.\n"
		"\nWhen the blazing sun is gone,"
		"\nWhen he nothing shines upon,"
		"Then you show your little light,\n"
		"Twinkle, twinkle all the night. \n";

	system("pause");
	return 0;
}