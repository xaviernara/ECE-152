#include <iostream> 
using namespace std;
int main()
{
	double  a, b, c, d, e, f;
	a =  17.0 /  6.0;
	b = 36 % 5;
	c = 7 * 3 - (4 - 3);
	d = double(7 * 3) / double(4 * 3);
	e = double(8 * 4) / double(6 * 3);
	f = 7.8 / (6.3 * 6) + 1.1;

	cout << "17.0 /  6.0=" << a << "\n";
	cout << "36 % 5=" << b << "\n";
	cout << "7 * 3 - (4 - 3)=" << c << "\n";
	cout << "(7 * 3) /(4 * 3)=
		" << d << "\n";
	cout << "(8 * 4) / (6 * 3)=" << e << "\n";
	cout << "7.8 / (6.3 * 6) + 1.1=" << f << "\n";
	
	system("pause");
	return 0;




}
